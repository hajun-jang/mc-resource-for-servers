import requests
import time
from pathlib import Path

API_URL = "https://commons.wikimedia.org/w/api.php"
OUTPUT_DIR = Path(__file__).resolve().parent

session = requests.Session()
session.headers.update({
    "User-Agent": "MinecraftFontDownloaderBot/1.0 (hajun_workspace; contact: hajun.jang2013@gmail.com)"
})

for i in range(9, 26):
    # Commons의 실제 파일명
    filename = f"M-{i:02d}.png"

    # 저장할 파일명
    output_name = f"m{i:02d}.png"
    output_path = OUTPUT_DIR / output_name

    print(f"[{i:02d}/20] {filename} 검색 중...")

    params = {
        "action": "query",
        "format": "json",
        "titles": f"File:{filename}",
        "prop": "imageinfo",
        "iiprop": "url",
    }

    response = session.get(API_URL, params=params)
    response.raise_for_status()

    data = response.json()
    pages = data["query"]["pages"]
    page = next(iter(pages.values()))

    if "imageinfo" not in page:
        print(f"  ❌ 찾을 수 없음: {filename}")
        continue

    image_url = page["imageinfo"][0]["url"]

    print(f"  → {image_url}")

    image_response = session.get(image_url, stream=True)
    image_response.raise_for_status()

    with open(output_path, "wb") as f:
        for chunk in image_response.iter_content(chunk_size=1024 * 1024):
            if chunk:
                f.write(chunk)

    print(f"  ✓ 저장 완료: {output_name}")
    time.sleep(1.5) 

print("\n모든 파일 다운로드 완료!")